﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
public partial class Category : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmitCategory_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection();
        con.ConnectionString = @"data source = DESKTOP-3T8F8KD\RAHUL; user id = sa; password = abcd1234; initial catalog=Inventory;";
        con.Open();

        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandType = CommandType.Text;

        String sql = "INSERT INTO mst_Categories(category) VALUES('"+txtCategory.Text+"')";
        com.CommandText = sql;
        com.ExecuteNonQuery();
        con.Close();
    }
    protected void btnShowCategory_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection();
        con.ConnectionString = @"data source = DESKTOP-3T8F8KD\RAHUL; user id = sa; password = abcd1234; initial catalog=Inventory;";
        con.Open();

        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandType = CommandType.Text;
        string pattrn = txtsrchCat.Text + '%';
        String sql = "SELECT [category] FROM [Inventory].[dbo].[mst_Categories] where category like '" + pattrn + "' ";
        com.CommandText = sql;
        SqlDataReader rd = com.ExecuteReader();
        grdCat.DataSource = rd;
        grdCat.DataBind();
        rd.Close();
        con.Close();
    }
}