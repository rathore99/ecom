﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient; 
public partial class addCompany : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        fillDdl();
    }

    protected void fillDdl()
    {
        // for connection
        SqlConnection con = new SqlConnection();
        con.ConnectionString = @"data source = DESKTOP-3T8F8KD\RAHUL; user id = sa; password = abcd1234; initial catalog=Inventory;";
        con.Open();

        // for command
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandType = CommandType.Text;

        String sql = "SELECT id, City FROM mst_Cities";
        com.CommandText = sql;
        SqlDataReader rd = com.ExecuteReader();
        ddlCity.DataSource = rd;
        ddlCity.DataTextField = "City";
        ddlCity.DataValueField = "id";
        ddlCity.DataBind();
        rd.Close();
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

    }
}