﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
//using DAL;
public partial class AddCity : System.Web.UI.Page
{
    // ArrayList a=new ArrayList();
    DAL d = new DAL();
    BAL objB = new BAL();
    //SqlCommand com = d.retCom();
    protected void Page_Load(object sender, EventArgs e)
    {
        // if(IsPostBack)

    }
    protected void btnSubmitCity_Click(object sender, EventArgs e)
    {
        Props obj = new Props();
        obj.cityname = txtCityName.Text.Trim();
        objB.insertCity(obj);

        /*SqlConnection con = new SqlConnection();
        con.ConnectionString = @"data source = DESKTOP-3T8F8KD\RAHUL; user id = sa; password = abcd1234; initial catalog=Inventory;";
        con.Open();

        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandType = CommandType.Text;

        String sql = "INSERT INTO mst_Cities(City) VALUES('"+txtCityName.Text+"')";
        com.CommandText = sql;
        com.ExecuteNonQuery();
        con.Close();*/
    }
    protected void btnShow_Click(object sender, EventArgs e)
    {

        fillGrid();
    }

    protected void fillGrid()
    {
        Props obj = new Props();
        obj.cityname = txtSrchCity.Text.Trim();
        d.show(obj, grdCity);
                
            }


    protected void grdCity_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        
        //txtCityName.Text =e.CommandArgument.ToString();
    }

    /*   protected void btnDisp_Click(object sender, EventArgs e)
       {
           string str = string.Empty;
           string strname = string.Empty;
           foreach (GridViewRow gvrow in grdCity.Rows)
           {
               CheckBox chk = (CheckBox)gvrow.FindControl("chkSelect");
               if (chk != null & chk.Checked)
               {
                   str +=  gvrow.Cells[1].Text + ", ";
                
                   str += "<br />";
               }
           }
 
       }
       */
    /*
    protected void row_update(object sender, GridViewUpdateEventArgs e)
    {
        Response.Write("Updating");
    }
    protected void row_delete(object sender, GridViewDeleteEventArgs e)
    {
        grdCity.EditIndex = e.NewEditIndex;
        Response.Write("deleting");
    }
    protected void row_edit(object sender, GridViewEditEventArgs e)
    {
        Response.Write("edititing");
    }
    protected void cancel_update(object sender, GridViewCancelEditEventArgs e)
    {
        Response.Write("Update cancel");
    
    }*/
    protected void grdCity_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void edit(object sender, GridViewEditEventArgs e)
    {
       
    }
    protected void update(object sender, GridViewUpdateEventArgs e)
    {

    }
}
//{ }[]