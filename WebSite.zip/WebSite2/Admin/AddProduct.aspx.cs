﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
public partial class AddProduct : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {  if(!IsPostBack) {
        fillddlCat(); fillddlCom();
    }
    }
    protected void fillddlCom()
    {
        SqlConnection con = new SqlConnection();
        con.ConnectionString = @"data source = DESKTOP-3T8F8KD\RAHUL; user id = sa; password = abcd1234; initial catalog=Inventory;";
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandType = CommandType.Text;

        String sql = "SELECT id, companyName FROM mst_Companies";
        com.CommandText = sql;
        SqlDataReader rd = com.ExecuteReader();
        ddlCom.DataSource = rd;
        ddlCom.DataTextField = "companyName";
        ddlCom.DataValueField = "id";
        ddlCom.DataBind();
        rd.Close();
        
        // for search form 
        SqlDataReader rdS = com.ExecuteReader();
        ddlCompany.DataSource = rdS;
        ddlCompany.DataTextField = "companyName";
        ddlCompany.DataValueField = "id";
        ddlCompany.DataBind();
        rdS.Close();

        con.Close();
        
            
    }
    protected void fillddlCat ()
    {
        // for connection
        SqlConnection con = new SqlConnection();
        con.ConnectionString = @"data source = DESKTOP-3T8F8KD\RAHUL; user id = sa; password = abcd1234; initial catalog=Inventory;";
        con.Open();

        // for command
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandType = CommandType.Text;

        String sql = "SELECT id, category FROM mst_Categories;";
        com.CommandText = sql;
        SqlDataReader rd = com.ExecuteReader();
        ddlCat.DataSource = rd;
        ddlCat.DataTextField = "category";
        ddlCat.DataValueField = "id";
        ddlCat.DataBind();
        rd.Close();
        SqlDataReader rdS = com.ExecuteReader();
        ddlCategory.DataSource = rdS;
        ddlCategory.DataTextField = "category";
        ddlCategory.DataValueField = "id";
        ddlCategory.DataBind();
        rdS.Close();
        con.Close();



    }

    protected void ddlCat_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string fileExt = System.IO.Path.GetExtension(flPrdct.FileName.ToString());
        if (fileExt == ".png" | fileExt == ".jpg")
        {
            var uniqueFileName = string.Format(@"{0}", DateTime.Now.Ticks) + flPrdct.FileName.ToString();
            flPrdct.SaveAs(Request.PhysicalApplicationPath + "/Images/ProductImages/" + uniqueFileName);
            string uploadImg = "/Images/ProductImages/" + uniqueFileName;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"data source = DESKTOP-3T8F8KD\RAHUL; user id = sa; password = abcd1234; initial catalog=Inventory;";
            con.Open();

            SqlCommand com = new SqlCommand();
            com.Connection = con;
            com.CommandType = CommandType.Text;

            String sql = "INSERT INTO tbl_Product(categoryId, name, companyId, price,discription,qty,images) ";
            sql = sql + "VALUES('" + ddlCat.SelectedItem.Value + "','" + txtName.Text + "','" + ddlCom.SelectedItem.Value + "','" + txtPrice.Text + "','" + txtDiscrp.Text + "','" + txtQty.Text + "','" + uploadImg + "')";
            com.CommandText = sql;
            com.ExecuteNonQuery();
            con.Close();
        }
        else
        {
            lblMsg.CssClass = "lblClrRed";
            lblMsg.Visible = true;
            lblMsg.Text = "Required image file (.png,.jpg,.jpeg etc)";
        }
        
  }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        searchRes();
    }
    protected void searchRes()
    {
        SqlConnection con = new SqlConnection();
        con.ConnectionString = @"data source = DESKTOP-3T8F8KD\RAHUL; user id = sa; password = abcd1234; initial catalog=Inventory;";
        con.Open();

        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandType = CommandType.Text;

        String sqlSrch = "SELECT  [name] ,[price] FROM [Inventory].[dbo].[tbl_Product]  WHERE name = '" + txtName1.Text + "' or companyId = '" + ddlCompany.SelectedItem.Value + "' or categoryId = '" + ddlCategory.SelectedItem.Value + "'";
        com.CommandText = sqlSrch;
        SqlDataReader rd = com.ExecuteReader();
        grdRes.DataSource = rd;
        grdRes.DataBind();
        rd.Close();
        con.Close();


    }

    
}