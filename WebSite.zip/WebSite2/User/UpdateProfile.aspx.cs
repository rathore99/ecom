﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UpdateProfile : System.Web.UI.Page
{
    DAL d = new DAL();
    BAL balObj = new BAL();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["USERNAME"].ToString() != "")
        {
            updateUser();
        }
        else 
        {
            Response.Redirect("Loginform.aspx");
        }
    }
    protected void updateUser()
    {
        Props objProp = new Props();
        objProp.userid = Convert.ToInt32( Session["USERID"].ToString());
        balObj.getUserInfo(objProp);
        txtUpdateProfName.Text = objProp.Uname;
        txtUpdateProAdd.Text = objProp.useraddress;
        txtUpdateProEmail.Text = objProp.useremail;
        txtUpdateProMob.Text = objProp.usermobile;

        string sql = "select id,City from mst_Cities";
         
        d.fillDdl(ddlUpdateProCity, sql, "city", "id");
        ddlUpdateProCity.SelectedValue = objProp.city;
    }
}