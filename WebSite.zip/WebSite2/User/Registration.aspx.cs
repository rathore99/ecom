﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
public partial class Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        fillCity();
        
    }
    protected void fillCity()
    {
        // for connection
        SqlConnection con = new SqlConnection();
        con.ConnectionString = @"data source = DESKTOP-3T8F8KD\RAHUL; user id = sa; password = abcd1234; initial catalog=Inventory;";
        con.Open();

        // for command
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandType = CommandType.Text;

        String sql = "SELECT id, City FROM mst_Cities";
        com.CommandText = sql;
        SqlDataReader rd = com.ExecuteReader();
        ddlCity.DataSource = rd;
        ddlCity.DataTextField = "City";
        ddlCity.DataValueField = "id";
        ddlCity.DataBind();
        rd.Close();
        String sqlQ = "SELECT id, question FROM tbl_Question";
        com.CommandText = sqlQ;
        SqlDataReader rdS = com.ExecuteReader();
        ddlhqid.DataSource = rdS;
        ddlhqid.DataTextField = "question";
        ddlhqid.DataValueField = "id";
        ddlhqid.DataBind();
        rd.Close();

        con.Close();
    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {  //validation to check empty fields
        if (txtName.Text != "" & txtEmail.Text != "" & txtConPswrd.Text != "" & txtAnswer.Text != "" & txtAddress.Text != "" & txtContct.Text != "" & txtUname.Text != "")
        {   // to check password matching
            if (txtConPswrd.Text == txtPswrd.Text)
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = @"data source = DESKTOP-3T8F8KD\RAHUL; user id = sa; password = abcd1234; initial catalog=Inventory;";
                con.Open();

                SqlCommand com = new SqlCommand();
                com.Connection = con;
                com.CommandType = CommandType.Text;
                String sql = "INSERT INTO tbl_Person(name, address, mobile, email,city,username,password, questionId,answer) VALUES('" + txtName.Text + "','" + txtAddress.Text + "','" + txtContct.Text + "','" + txtEmail.Text + "','" + ddlCity.SelectedItem.Value + "','" + txtUname.Text + "','" + txtConPswrd.Text + "','" + ddlhqid.SelectedItem.Value + "','" + txtAnswer.Text + "' )";
                com.CommandText = sql;
                com.ExecuteNonQuery();
                con.Close();
                showLblMsg("registered Succesfully ", "lblClrGreen");
                Int64 i = 0;
                while (i++ < 10000000000) ;
                Response.Redirect("Loginform.aspx");
            }
            else
            {
                showLblMsg("Password did not match ", "lblClrRed");
            }
        }
        else
        {
            showLblMsg("Please fill all the mandatory fields", "lblClrRed");
        } 
        
    }
    //function to show error msg with proper styling
    protected void showLblMsg(string txt,string cssClassName)
    {
        lblMsg.CssClass = cssClassName;
        lblMsg.Visible = true;
        lblMsg.Text = txt;
    }
}