﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Product : System.Web.UI.Page
{
    DAL obj = new DAL();
    protected void Page_Load(object sender, EventArgs e)
    {
       obj.showProduct(rptrProduct);
    }
    protected void btnPlaceOrder_Click(object sender, EventArgs e)
    {
        Response.Redirect("UpdateProfile.aspx");
    }
}