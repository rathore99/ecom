﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
public partial class Loginform : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSignUp_Click(object sender, EventArgs e)
    {
        Response.Redirect("Registration.aspx");
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        login();
    }
    protected void login()
    {
        SqlConnection con = new SqlConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
        con.Open();

        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandType = CommandType.Text;

        String sqlSrch = "Select id,username,password from tbl_Person where username ='"+txtUserName.Text+"' and password='"+txtPassword.Text+"';";
        com.CommandText = sqlSrch;
        SqlDataReader rd = com.ExecuteReader();
        if (rd.HasRows)
        {
            rd.Read();
            Session["USERNAME"] = rd.GetValue(1);
            Session["USERID"] = rd.GetValue(0);
            Response.Redirect("Product.aspx?session=" + Session["USERNAME"]+Session["USERID"]);

        }
        else 
        {
            Response.Redirect("~/Loginform.aspx");
        }

        rd.Close();
        con.Close();

    }

}
//{ }[]