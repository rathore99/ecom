﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
//{}
/// <summary>
/// Summary description for Props
/// </summary>
public class Props
{
    public Props()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    #region Product
    public int id { get; set; }
    public int categoryId { get; set; }
    public string name  { get; set; }
    public int companyId { get; set; }
    public int price  { get; set; }
    
    #endregion
    #region City
    public int cityid { get; set; }
    public string cityname { get; set; }
    #endregion
    #region User
    public Int32 userid { get; set; }
    public string username { get; set; }
    public string useremail { get; set; }
    public string useraddress { get; set; }
    public string Uname { get; set; }
    public string usermobile { get; set; }
    public string city { get; set; }
    #endregion
}