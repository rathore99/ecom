﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
//new namespace ncluded 
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
/// <summary>
/// Summary description for DAL {}
/// </summary>
public class DAL
{
    SqlConnection con = new SqlConnection();
    SqlCommand com = new SqlCommand();
    public DAL()
    {
        con.ConnectionString = @"data source = DESKTOP-3T8F8KD\RAHUL; user id = sa; password = abcd1234; initial catalog=Inventory;";
        con.Open();
        com.Connection = con;
        com.CommandType = CommandType.Text;

    }
    public SqlCommand retCom()
    {
        return com;
    }
    public void fillDdl(DropDownList ddl, string sql, string textVal, string valVal)
    {
        com.CommandText = sql;
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataTable dt = new DataTable();
        da.Fill(dt);

        ddl.DataSource = dt;
        ddl.DataTextField = textVal;
        ddl.DataValueField = valVal;
        ddl.DataBind();
        // con.Close();
    }

    #region Products
    public void insertProducts()
    {
    }
    #endregion
    #region City
    public void insertCity(Props objProp)
    {
        string sql = " Insert into mst_Cities(city  ) ";
        sql = sql + "  values('" + objProp.cityname + "')";
        com.CommandText = sql;
        com.ExecuteNonQuery();
    }
    public void show(Props objProp, GridView grdCity)
    {
        string pattrn = objProp.cityname + '%';
        String sql = "SELECT id, [City] FROM [Inventory].[dbo].[mst_Cities] ";
        if (pattrn == "")
        {

        }
        else {
 sql= sql + "where City like '" + pattrn + "' "; 

        }
        
        com.CommandText = sql;
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataTable dt = new DataTable();
        da.Fill(dt);

        if (dt.Rows.Count > 0)
        {
            grdCity.DataSource = dt;
            grdCity.DataBind();
        }
        else
        {
            dt.Rows.Add(dt.NewRow());
            grdCity.DataSource = dt;
            grdCity.DataBind();
            int columnCount = grdCity.Columns.Count;
            grdCity.Rows[0].Cells.Clear();
            grdCity.Rows[0].Cells.Add(new TableCell());
            grdCity.Rows[0].Cells[0].ColumnSpan = columnCount;
            grdCity.Rows[0].Cells[0].Text = "NO Record Found!!!";

        }

    }
    #endregion
    public void showUser(Props objProp)
    {   Int32 userid = objProp.userid;
    string sql = " select name, address, mobile, email, c.City from tbl_Person as p, mst_Cities as c where p.id =  " + userid.ToString();
    sql = sql + " and c.id = p.city";
        com.CommandText = sql;
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count == 1)
        {
            objProp.Uname = dt.Rows[0]["name"].ToString();
            objProp.useraddress = dt.Rows[0]["address"].ToString();
            objProp.usermobile = dt.Rows[0]["mobile"].ToString();
            objProp.useremail = dt.Rows[0]["email"].ToString();
            objProp.city =dt.Rows[0]["city"].ToString();
        }
        else 
        { 
          
        }
    }
    public void  showProduct(Repeater rptrProduct, Int32 ) 
    {  
        string sql = " select * from tbl_Product ";
        com.CommandText = sql;
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataTable dt = new DataTable();
        da.Fill(dt);
        rptrProduct.DataSource = dt;
        rptrProduct.DataBind();

    }

}