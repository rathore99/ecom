﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BAL
/// </summary>
public class BAL
{
    DAL objdal = new DAL();
    public BAL()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public void insertProd(Props obj)
    {
        //objdal.insertProducts(obj);
    }
    public void insertCity(Props obj)
    {
        objdal.insertCity(obj);
    }
    public void getUserInfo(Props obj)
    {
        objdal.showUser(obj);
    }
}